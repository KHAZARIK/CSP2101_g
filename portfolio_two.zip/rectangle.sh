#!/bin/bash

# Checks if the rectangle.txt file exists in the current directory.
# If the file do not exist, then the program will send exit code 0.
if ! [ -f rectangle.txt ]; then
       echo "file doesn't exist!!"
       exit 0
else
	# sed command replaces 'Rec' to 'Name:Rec' globally.
	# sed command replaces ',' to '\t Height:', first occurence in every line.
	# sed command replaces ',' to '\t Width:', first occurence in every line.
	# sed command replaces ',' to '\t Area: ', first occurence in every line.
	# sed command deletes the first line of the file rectangle.txt.
	# sed command replaces ',' to '\t Colour:', first occurence in every line.
	# sed command completes the above mentioned task from rectangle.txt and saved into rectangle_f.txt
	sed -e "s/Rec/ Name:Rec/g"\
    	-e "s/,/ \t Height: /"\
	    -e "s/,/ \t Width: /"\
       	-e "s/,/ \t Area: /"\
	    -e "1d"\
	    -e "s/,/ \t Colour: /" rectangle.txt > rectangle_f.txt	    
	
	cat rectangle_f.txt # to display data from rectangle_f.txt 
	printf "\n\n"
fi

