#!/bin/bash
# Author Krishnarjun Hazarika
# 10376173 Assignment_three [Edith Cowan University]


# following command will check if there is file called gallery.php?folder=152
if ! [[ -f gallery.php?folder=152 ]]
then
	wget -q https://www.ecu.edu.au/service-centres/MACSC/gallery/gallery.php?folder=152
fi

if ! [[ -f ur.txt ]] #checks if ur.txt file exists
then 
	sed -i -e 's/<img src="//g' \ # using sed command to replace <img src= in ""
		   -e 's/" alt="DSC0.*$//g' gallery.php?folder=152  #using sed command to replace " alt="DSC0.*$ to ""
	grep "https://secure.ecu.edu.au/service-centres" gallery.php?folder=152 > ur.txt #using grep to find a certain pattern from the file
fi

# User will be requested to input 1, 2, 3, 4. Each case would perform a different function
printf "\n 1) Download a specific THUMBNAIL, ie DSC01566 \n 2) Download all THUMBNAILS \n 3) Download specific number of images \n 4) Download random number of images \n"
printf "Enter choice: "
read VAR

case $VAR in 
	1)
		# While loop started because we are not aware about the number of pics available from the website
		while true; do

			printf " Enter a number between 1533 and 2042: " #will request user to input a number between 1533 and 2042
			read VAR # reads the input
			if [[ $VAR -ge 1533 ]] && [[ $VAR -le 2042 ]] && [[ $VAR =~ ^[+-]?[0-9]*$ ]] # will validate if the input is an integer between 1533 and 2042
			then
				wget -P ./one -q grep "https://secure.ecu.edu.au/service-centres/MACSC/gallery/152/DSC0$VAR.jpg" ur.txt	#using wget to download the link which would provided by grep from the file 	
				if [[ -f ./one/DSC0$VAR.jpg ]] #checks if the  jpeg file exists in the following folder called one
				then 
					size_image=$( stat -c%s ./one/DSC0$VAR.jpg ) #captures the size of the image
					printf " Downloading: DSC0$VAR \t Filename: DSC0$VAR \t File size: $size_image Kb \n " #displays the statistics of image downloaded 
					break #breaking out of the loop
				else
					printf "Image specified doesnt exist in the website. Try 1533!! \n" #notifies user if the image specified doesn't exist in the website				
				fi
			else
				printf " Image specified do-not exist!! \n" 
			fi	
		done
		;;
	2)
		#this function will download all the images within the range 1533 and 2042
		for (( i=1533; i<= 2042; i++ )); do #using c style for loop  because we know how many times we will iterate
			if ! [[ -f ./two/DSC0$i ]] #checks if the particular file exists in the folder two
			then 
				wget -P ./four -q grep "https://secure.ecu.edu.au/service-centres/MACSC/gallery/152/DSC0$i.jpg" ur.txt #using wget to download image from the html link provided by grep
				size_image=$( stat -c%s ./two/DSC0$i.jpg ) #shows statistics about the image downloaded.
				printf "downloading DSC0$i.jpg  \t Filename: DSC0$i.jpg  \t File size: $size_image Kb \n" # displays the statistics of the image downloaded
			else
				printf "image exists!! moving on" #notifies user if a certain file already exists in the folder
			fi
		done
		
		#wget -q -i ur.txt -P ./two
		#echo "download all image.... \n"
		
		;;

	3) 	
		# this function will download images within the range provided by the user.
		while true; do
			echo "Enter starting and ending range: " # requests user to input start range
			read start_range # reads input from user
			echo "Enter ending range: " #requests user to input end_range
			read end_range #reads end range
			# the following if condition would do an input validation
			if [[ $start_range -ge 1533 ]] && [[ $start_range -lt 2042 ]] && [[ $start_range =~ ^[+-]?[0-9]*$ ]] && [[ $end_range -gt 1533 ]] && [[ $end_range -le 2042 ]] && [[ $end_range =~ ^[+-]?[0-9]*$ ]]
			then
				for ((index = $start_range; index <= $end_range; index ++)); do #for loop will iterate from starting range to end range.
					if ! [[ -f ./three_one/DSC0$index.jpg ]] #checks if the following image exists in the folder
					then 
						wget -P ./three_one -q grep "https://secure.ecu.edu.au/service-centres/MACSC/gallery/152/DSC0$index.jpg" ur.txt #downloads the image using wget and grep provides the hyperlink.
						size_image=$( stat -c%s ./three_one/DSC0$index.jpg ) #stores the statistics of the image downloaded.
						printf "downloading DSC0$index  \t Filename: DSC0$index  \t File size: $size_image Kb \n" #displays the statistics of the image downloaded
					else	
						printf " File already exists!! File name: DSC0$index \n" #notifies user if a certain image already exists.
					fi
				done #ends loop
				break
			else
				printf "Invalid input please try again!! \n"
			fi
		
		done	
		;;

	4)
		# this function will download random number of images based on user input.

		# the sed command strips the hyperlink and saves only image number after DSC0 into random.txt
		sed -e "s%.*https://secure.ecu.edu.au/service-centres/MACSC/gallery/152/DSC0%%" \
			-e "s/.jpg//" \
			-e "s/\t\t\t\t/g/" ur.txt > random.txt
		
		echo "Please enter a number between 1 - 75: " #requests user to input a number between 1-75
		read num

		for (( index=0; index< $num; index++ )); do # for loop will iterate number of images requested by user
			i=$(shuf -n 1 random.txt) #generates random number
			if ! [[ -f ./four/DSC0$index ]] #checks if the file exists.
			then 
				wget -P ./four -q grep "https://secure.ecu.edu.au/service-centres/MACSC/gallery/152/DSC0$i.jpg" ur.txt #uses wget to download the image
				size_image=$( stat -c%s ./four/DSC0$i.jpg ) #image statistics will be saved into size_image
				printf "downloading DSC0$i.jpg  \t Filename: DSC0$i.jpg  \t File size: $size_image Kb \n" #displays image statistics
			else
				printf "image exists!! moving on"
			fi
		done
		;;


	*)
		printf "try again!!"
		;;
esac

